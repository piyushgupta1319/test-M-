import {
  Calendar,
  CheckCircle,
  Clock,
} from "lucide-react";

import DashboardStats from "../DashboardStats";

const STAT_CARDS = [
  {
    title: "Total Events",
    value: "24",
    icon: Calendar,
    change: 5,
    changeText: "this month",
    color: "blue" as const,
  },
  {
    title: "Registered Events",
    value: "12",
    icon: CheckCircle,
    change: 3,
    changeText: "since last week",
    color: "green" as const,
  },
  {
    title: "Notifications",
    value: "8",
    icon: Clock,
    change: 2,
    changeText: "this week",
    color: "orange" as const,
  },
  {
    title: "Certificates",
    value: "5",
    icon: Calendar,
    change: 2,
    changeText: "earned recently",
    color: "purple" as const,
  },
];

export default function StatsSection() {
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">

      {STAT_CARDS.map((stat) => (

        <DashboardStats
          key={stat.title}
          title={stat.title}
          value={stat.value}
          icon={stat.icon}
          change={stat.change}
          changeText={stat.changeText}
          color={stat.color}
        />
      ))}

    </div>
  );
}