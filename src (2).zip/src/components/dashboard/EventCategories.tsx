import { Code, Trophy, Music, Briefcase } from "lucide-react";

const categories = [
  {
    name: "Technical",
    value: 12,
    icon: Code,
    color: "bg-blue-50 text-blue-600",
  },
  {
    name: "Sports",
    value: 8,
    icon: Trophy,
    color: "bg-green-50 text-green-600",
  },
  {
    name: "Cultural",
    value: 6,
    icon: Music,
    color: "bg-purple-50 text-purple-600",
  },
  {
    name: "Workshops",
    value: 5,
    icon: Briefcase,
    color: "bg-orange-50 text-orange-600",
  },
];

export default function EventCategories() {
  return (
    <div className="bg-white border border-slate-200 rounded-3xl shadow-sm p-8">

      <h2 className="text-2xl font-bold text-slate-900 mb-8">
        Event Categories
      </h2>

      <div className="space-y-5">

        {categories.map((item) => {
          const Icon = item.icon;

          return (
            <div
              key={item.name}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-4">

                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${item.color}`}>
                  <Icon size={22} />
                </div>

                <div>
                  <h3 className="font-semibold text-slate-900">
                    {item.name}
                  </h3>

                  <p className="text-sm text-slate-500">
                    {item.value} events
                  </p>
                </div>

              </div>

              <span className="text-xl font-bold text-slate-900">
                {item.value}
              </span>

            </div>
          );
        })}

      </div>

    </div>
  );
}