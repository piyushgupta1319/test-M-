import DashboardHero from "@/components/dashboard/DashboardHero";
import StatsSection from "@/components/dashboard/StatsSection";
import QuickActions from "@/components/dashboard/QuickActions";
import UpcomingEvents from "@/components/dashboard/UpcomingEvents";
import RecentActivities from "@/components/dashboard/RecentActivities";
import EventCategories from "@/components/dashboard/EventCategories";
import ParticipationStats from "@/components/dashboard/ParticipationStats";
import EngagementOverview from "@/components/dashboard/EngagementOverview";

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-slate-100">

      <div className="max-w-7xl mx-auto px-6 py-10 space-y-10">

        <DashboardHero />

        <StatsSection />

        <QuickActions />

        <div className="grid lg:grid-cols-2 gap-10">

          <UpcomingEvents />

          <RecentActivities />

        </div>

        <div className="grid lg:grid-cols-3 gap-10">

          <EventCategories />

          <ParticipationStats />

          <EngagementOverview />

        </div>

      </div>

    </div>
  );
}